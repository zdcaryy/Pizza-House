var a=1;
var a=2;
console.log(a);